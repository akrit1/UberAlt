package com.javapapers.firebaseauthdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class QueueActivity extends AppCompatActivity {
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queue);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String temp = user.getEmail();
        String curKey = temp.substring(0,temp.length()-4);

        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        mDatabase.addValueEventListener(postListener);
    }

    public class Person {
        public String name;
        public double cLat;
        public double cLon;
        public double dLat;
        public double dLon;

        public Person(){}

        public Person(String name, double cLat, double cLon, double dLat, double dLon) {
            this.name = name;
            this.cLat = cLat;
            this.cLon = cLon;
            this.dLat = dLat;
            this.dLon = dLon;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getcLat() {
            return cLat;
        }

        public void setcLat(double cLat) {
            this.cLat = cLat;
        }

        public double getcLon() {
            return cLon;
        }

        public void setcLon(double cLon) {
            this.cLon = cLon;
        }

        public double getdLat() {
            return dLat;
        }

        public void setdLat(double dLat) {
            this.dLat = dLat;
        }

        public double getdLon() {
            return dLon;
        }

        public void setdLon(double dLon) {
            this.dLon = dLon;
        }
    }
}

